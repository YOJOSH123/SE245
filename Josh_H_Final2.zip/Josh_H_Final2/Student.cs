﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace Josh_H_Final2
{
    class Student
    {
        private string fname;
        private string lname;
        private double gpa;
        private int credits;
        private int age;
        private int student_id;

        protected string feedback;

        public string Fname
        {
            get
            {
                return fname;
            }
            set
            {
                if(Validation.IsItFilledIn(value))
                {
                    fname = value;
                }
                else
                {
                    feedback += "\nERROR: First must be filled in.";
                }
            }
        }

        public string Lname
        {
            get
            {
                return lname;
            }
            set
            {
                if (Validation.IsItFilledIn(value))
                {
                    lname = value;
                }
                else
                {
                    feedback += "\nERROR: Last must be filled in.";
                }
            }
        }

        public double Gpa
        {
            get
            {
                return gpa;
            }
            set
            {
                if (Validation.IsMinimumAmount(value))
                {
                    gpa = value;
                }
                else
                {
                    feedback += "\nERROR: GPA must be greater than or equal to 0 and less than or equal to 4.";
                }
            }
        }

        public int Credits
        {
            get
            {
                return credits;
            }
            set
            {
                if (Validation.IsMinimumAmount(value))
                {
                    credits = value;
                }
                else
                {
                    feedback += "\nERROR: Credits must be greater than 0.";
                }
            }
        }

        public int Age
        {
            get
            {
                return age;
            }
            set
            {
                if (Validation.IsMinimumAmount(value))
                {
                    age = value;
                }
                else
                {
                    feedback += "\nERROR: Age must be greater than 0.";
                }
            }
        }

        public int Student_id
        {
            get
            {
                return student_id;
            }
            set
            {
                student_id = value;
            }
        }

        public Student()
        {
            fname = "";
            lname = "";
            gpa = 0;
            credits = 0;
            age = 0;
            feedback = "";
        }

        public string Feedback
        {
            get { return feedback; }
        }

        private string GetConnected()
        {
            return "Server=sql.neit.edu\\studentsql server, 4500;Database=SE245_JHorovitz;User Id=SE245_JHorovitz;Password=008003885;";
        }

        public string AddARecord()
        {
            string strResults = "";

            SqlConnection Conn = new SqlConnection();

            Conn.ConnectionString = GetConnected();

            string strSQL = "INSERT INTO Students (First, Last, GPA, Credits, Age)" +
                            "VALUES (@First, @Last, @GPA, @Credits, @Age)";

            SqlCommand comm = new SqlCommand();
            comm.CommandText = strSQL;
            comm.Connection = Conn;

            comm.Parameters.AddWithValue("@First", Fname);
            comm.Parameters.AddWithValue("@Last", Lname);
            comm.Parameters.AddWithValue("@GPA", Gpa);
            comm.Parameters.AddWithValue("@Credits", Credits);
            comm.Parameters.AddWithValue("@Age", Age);

            try
            {
                Conn.Open();
                int intRecs = comm.ExecuteNonQuery();
                strResults = $"\nSUCCESS: Inserted {intRecs} records.";
                Conn.Close();
            }
            catch (Exception err)
            {
                strResults = "\nERROR: " + err.Message;
            }
            finally
            {
            }

            return strResults;
        }

        public DataSet SearchStudents(string strFname, string strLname)
        {
            DataSet ds = new DataSet();

            SqlCommand comm = new SqlCommand();

            string strSQL = "SELECT Student_id, First, Last FROM Students WHERE 0=0";

            if(strFname.Length > 0)
            {
                strSQL += " AND First LIKE @First";
                comm.Parameters.AddWithValue("@First", "%" + strFname + "%");
            }
            if (strLname.Length > 0)
            {
                strSQL += " AND Last LIKE @Last";
                comm.Parameters.AddWithValue("@Last", "%" + strLname + "%");
            }

            SqlConnection conn = new SqlConnection();
            string strConn = @GetConnected();
            conn.ConnectionString = strConn;
            comm.Connection = conn;
            comm.CommandText = strSQL;
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = comm;

            conn.Open();
            da.Fill(ds, "Students_Temp");
            conn.Close();

            return ds;
        }

        public SqlDataReader FindOneStudent(int intStudent_id)
        { 
            SqlConnection conn = new SqlConnection();
            SqlCommand comm = new SqlCommand();

            string strConn = GetConnected();

            string sqlString =
           "SELECT * FROM Students WHERE Student_id = @Student_id;";

            conn.ConnectionString = strConn;

            comm.Connection = conn;
            comm.CommandText = sqlString;
            comm.Parameters.AddWithValue("@Student_id", intStudent_id);

            conn.Open();

            return comm.ExecuteReader();
        }

        public string DeleteOneStudent(int intStudent_id)
        {
            Int32 intRecords = 0;
            string strResult = "";

            SqlConnection conn = new SqlConnection();
            SqlCommand comm = new SqlCommand();

            string strConn = GetConnected();

            string sqlString = "DELETE FROM Students WHERE Student_id = @Student_id;";

            conn.ConnectionString = strConn;

            comm.Connection = conn;
            comm.CommandText = sqlString;
            comm.Parameters.AddWithValue("@Student_id", intStudent_id);

            try
            {
                conn.Open();

                intRecords = comm.ExecuteNonQuery();
                strResult = intRecords.ToString() + " Records Deleted.";
            }
            catch (Exception err)
            {
                strResult = "ERROR: " + err.Message;
            }
            finally
            {
                conn.Close();
            }
            return strResult;
        }

        public string UpdateARecord()
        {
            Int32 intRecord = 0;
            string strResult = "";

            string strSQL = "UPDATE Students SET First = @First, Last = @Last, GPA = @GPA, Credits = @Credits, Age = @Age WHERE Student_id = @Student_id";

            SqlConnection conn = new SqlConnection();

            string strConn = GetConnected();
            conn.ConnectionString = strConn;

            SqlCommand comm = new SqlCommand();
            comm.CommandText = strSQL;
            comm.Connection = conn;

            comm.Parameters.AddWithValue("@First", Fname);
            comm.Parameters.AddWithValue("@Last", Lname);
            comm.Parameters.AddWithValue("@GPA", Gpa);
            comm.Parameters.AddWithValue("@Credits", Credits);
            comm.Parameters.AddWithValue("@Age", Age);
            comm.Parameters.AddWithValue("@Student_id", Student_id);

            try
            {
                conn.Open();

                intRecord = comm.ExecuteNonQuery();
                strResult = intRecord.ToString() + " Records Updated.";
            }
            catch (Exception err)
            {
                strResult = "ERROR: " + err.Message;
            }
            finally
            {
                conn.Close();
            }
            return strResult;

        }
    }
}
