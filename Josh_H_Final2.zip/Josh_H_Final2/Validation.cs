﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Josh_H_Final2
{
    class Validation
    {
        public static bool IsItFilledIn(string temp)
        {
            bool result = false;

            if (temp.Length > 0)
            {
                result = true;
            }

            return result;
        }

        public static bool IsMinimumAmount(double temp)
        {
            bool blnResult;

            if (temp >= 0 && temp <= 4)
            {
                blnResult = true;
            }
            else
            {
                blnResult = false;
            }

            return blnResult;
        }

        public static bool IsMinimumAmount(int temp)
        {
            bool blnResult;

            if (temp >= 0)
            {
                blnResult = true;
            }
            else
            {
                blnResult = false;
            }

            return blnResult;
        }
    }
}
