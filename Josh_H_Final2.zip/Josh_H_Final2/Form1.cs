﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Josh_H_Final2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void LblFeedback_Click(object sender, EventArgs e)
        {

        }

        private void BtnSubmit_Click(object sender, EventArgs e)
        {
            Student temp = new Student();

            temp.Fname = txtFname.Text;
            temp.Lname = txtLname.Text;
            temp.Gpa = double.Parse(txtGpa.Text);
            temp.Credits = int.Parse(txtCredits.Text);
            temp.Age = int.Parse(txtAge.Text);

            lblFeedback.Text = temp.Fname + "\n" + temp.Lname + "\n" + temp.Gpa + "\n" + temp.Credits + "\n" + temp.Age;

            if(!temp.Feedback.Contains("ERROR:"))
            {
                lblFeedback.Text += temp.AddARecord();
            }
            else
            {
                lblFeedback.Text += temp.Feedback;
            }
        }

        public Form1(int intStudent_id)
        {
            InitializeComponent();

            Student temp = new Student();
            SqlDataReader dr = temp.FindOneStudent(intStudent_id);

            while (dr.Read())
            {
                //Take the Name(s) from the datareader and copy them
                // into the appropriate text fields
                txtFname.Text = dr["First"].ToString();
                txtLname.Text = dr["Last"].ToString();
                txtGpa.Text = dr["GPA"].ToString();
                txtCredits.Text = dr["Credits"].ToString();
                txtAge.Text = dr["Age"].ToString();

                lblStudent_id.Text = dr["Student_id"].ToString();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            Int32 intStudent_id = Convert.ToInt32(lblStudent_id.Text);

            Student temp = new Student();

            lblFeedback.Text = temp.DeleteOneStudent(intStudent_id); 
        }

        private void BtnUpdate_Click(object sender, EventArgs e)
        {
            Student temp = new Student();

            temp.Fname = txtFname.Text;
            temp.Lname = txtLname.Text;
            temp.Gpa = double.Parse(txtGpa.Text);
            temp.Credits = int.Parse(txtCredits.Text);
            temp.Age = int.Parse(txtAge.Text);

            temp.Student_id = Convert.ToInt32(lblStudent_id.Text);

            if (!temp.Feedback.Contains("Error:"))
            {
                lblFeedback.Text = temp.UpdateARecord();
            }
            else
            {
                lblFeedback.Text = temp.Feedback;
            }
        }
    }
}
