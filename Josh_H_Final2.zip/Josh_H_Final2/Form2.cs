﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Josh_H_Final2
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void BtnSearch_Click(object sender, EventArgs e)
        {
            Student temp = new Student();
            DataSet ds = temp.SearchStudents(strFname.Text, strLname.Text);

            dbResults.DataSource = ds;
            dbResults.DataMember = ds.Tables["Students_temp"].ToString();
        }

        private void DbResults_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string strStudent_id = dbResults.Rows[e.RowIndex].Cells[0].Value.ToString();
            MessageBox.Show(strStudent_id);

            int intStudent_id = Convert.ToInt32(strStudent_id);

            Form1 Editor = new Form1(intStudent_id);
            Editor.ShowDialog();
        }
    }
}
