﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace Josh_HMidTerm
{
    class PersonV2 : Person
    {
        private string cell_phone;
        private string facebook;

        private int persons_ID;

        public string Cell_phone
        {
            get
            {
                return cell_phone;
            }
            set
            {
                if (Validation.ValidPhone(value))
                {
                    cell_phone = value;
                }
                else
                {
                    feedback += "\nInvalid Phone";
                }
            }
        }

        public string FaceBook
        {
            get
            {
                return facebook;
            }
            set
            {
                facebook = value;
            }
        }

        public Int32 Persons_ID
        {
            get
            {
                return persons_ID;
            }
            set
            {
                persons_ID = value;
            }
        }

        public PersonV2()
        {
            cell_phone = "";
            facebook = "";
        }

        public string AddARecord()
        {
            string strResults = "";

            SqlConnection Conn = new SqlConnection();

            Conn.ConnectionString = @"Server=sql.neit.edu\studentsql server, 4500;Database=SE245_JHorovitz;User Id=SE245_JHorovitz;Password=008003885;";

            string strSQL = "INSERT INTO Persons (First, Middle, Last, Street1, Street2, City, State, Zip, Phone, FaceBook) VALUES (@First, @Middle, @Last, @Street1, @Street2, @City, @State, @Zip, @Phone, @FaceBook)";

            SqlCommand comm = new SqlCommand();
            comm.CommandText = strSQL;
            comm.Connection = Conn;

            comm.Parameters.AddWithValue("@First", FName);
            comm.Parameters.AddWithValue("@Middle", MName);
            comm.Parameters.AddWithValue("@Last", LName);
            comm.Parameters.AddWithValue("@Street1", Street1);
            comm.Parameters.AddWithValue("@Street2", Street2);
            comm.Parameters.AddWithValue("@City", City);
            comm.Parameters.AddWithValue("@State", State);
            comm.Parameters.AddWithValue("@Zip", Zip);
            comm.Parameters.AddWithValue("Phone", Phone);
            comm.Parameters.AddWithValue("@FaceBook", FaceBook);

            try
            {
                Conn.Open();
                int intRecs = comm.ExecuteNonQuery();
                strResults = $"SUCCESS: Inserted {intRecs} records.";
                Conn.Close();
            }
            catch (Exception err)
            {
                strResults = "ERROR: " + err.Message;
            }
            finally
            {

            }

            return strResults;
        }

        public DataSet SearchPersons(String strFName, String strLName)
        {
            DataSet ds = new DataSet();

            SqlCommand comm = new SqlCommand();

            String strSQL = "SELECT Persons_ID, First, Last FROM Persons WHERE 0=0";

            if(strFName.Length > 0)
            {
                strSQL += " AND First LIKE @First";
                comm.Parameters.AddWithValue("@First", "%" + strFName + "%");
            }
            if(strLName.Length > 0)
            {
                strSQL += " AND Last LIKE @Last";
                comm.Parameters.AddWithValue("@Last", "%" + strLName + "%");
            }

            SqlConnection conn = new SqlConnection();
            string strConn = @GetConnected();
            conn.ConnectionString = strConn;
            comm.Connection = conn;
            comm.CommandText = strSQL;
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = comm;

            conn.Open();
            da.Fill(ds, "Persons_Temp");
            conn.Close();

            return ds;
        }

        public SqlDataReader FindOnePerson(int intPersons_ID)
        {
            //Create and Initialize the DB Tools we need
            SqlConnection conn = new SqlConnection();
            SqlCommand comm = new SqlCommand();

            //My Connection String
            string strConn = GetConnected();

            //My SQL command string to pull up one EBook's data
            string sqlString =
           "SELECT * FROM Persons WHERE Persons_ID = @Persons_ID;";

            //Tell the connection object the who, what, where, how
            conn.ConnectionString = strConn;

            //Give the command object info it needs
            comm.Connection = conn;
            comm.CommandText = sqlString;
            comm.Parameters.AddWithValue("@Persons_ID", intPersons_ID);

            //Open the DataBase Connection and Yell our SQL Command
            conn.Open();

            //Return some form of feedback
            return comm.ExecuteReader();   //Return the dataset to be used by others (the calling form)

        }

        public string DeleteOnePerson(int intPersons_ID)
        {
            Int32 intRecords = 0;
            string strResult = "";

            SqlConnection conn = new SqlConnection();
            SqlCommand comm = new SqlCommand();

            string strConn = GetConnected();

            string sqlString = "DELETE FROM Persons WHERE Persons_ID = @Persons_ID;";

            conn.ConnectionString = strConn;

            comm.Connection = conn;
            comm.CommandText = sqlString;
            comm.Parameters.AddWithValue("@Persons_ID", intPersons_ID);

            try
            {
                conn.Open();

                intRecords = comm.ExecuteNonQuery();
                strResult = intRecords.ToString() + " Records Deleted.";
            }
            catch (Exception err)
            {
                strResult = "ERROR: " + err.Message;
            }
            finally
            {
                conn.Close();
            }
            return strResult;
        }

        public string UpdateARecord()
        {
            Int32 intRecord = 0;
            string strResult = "";

            string strSQL = "UPDATE Persons SET First = @First, Middle = @Middle, Last = @Last, Street1 = @Street1, Street2 = @Street2, City = @City, State = @State, Zip = @Zip, Phone = @Phone, FaceBook = @FaceBook WHERE Persons_ID = @Persons_ID";

            SqlConnection conn = new SqlConnection();

            string strConn = GetConnected();
            conn.ConnectionString = strConn;

            SqlCommand comm = new SqlCommand();
            comm.CommandText = strSQL;
            comm.Connection = conn;

            comm.Parameters.AddWithValue("@First", FName);
            comm.Parameters.AddWithValue("@Middle", MName);
            comm.Parameters.AddWithValue("@Last", LName);
            comm.Parameters.AddWithValue("@Street1", Street1);
            comm.Parameters.AddWithValue("@Street2", Street2);
            comm.Parameters.AddWithValue("@City", City);
            comm.Parameters.AddWithValue("@State", State);
            comm.Parameters.AddWithValue("@Zip", Zip);
            comm.Parameters.AddWithValue("Phone", Phone);
            comm.Parameters.AddWithValue("@FaceBook", FaceBook);
            comm.Parameters.AddWithValue("@Persons_ID", Persons_ID);

            try
            {
                conn.Open();

                intRecord = comm.ExecuteNonQuery();
                strResult = intRecord.ToString() + " Records Updated.";
            }
            catch (Exception err)
            {
                strResult = "ERROR: " + err.Message;
            }
            finally
            {
                conn.Close();
            }
            return strResult;
     
        }
           

        private string GetConnected()
        {
            return "Server=sql.neit.edu\\studentsql server, 4500;Database=SE245_JHorovitz;User Id=SE245_JHorovitz;Password=008003885;";
        }


    }
}
