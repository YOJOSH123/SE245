﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Josh_HMidTerm
{
    class Validation
    {
        //validates email
        public static bool ValidEmail(string temp)
        {
            bool blnResult = true;

            int atlocation = temp.IndexOf("@");
            int NextatLocation = temp.IndexOf("@", atlocation + 1);

            int periodlocation = temp.LastIndexOf(".");

            //val totl length
            if (temp.Length < 8)
            {
                blnResult = false;
            }
            //val loc of @
            else if (atlocation < 2)
            {
                blnResult = false;
            }
            //val loc of period
            else if (periodlocation + 2 > (temp.Length))
            {
                blnResult = false;
            }

            return blnResult;
        }

        //validates phone
        public static bool ValidPhone(string temp)
        {
            bool blnResult = true;

            //val total length of phone number
            if(temp.Length < 10)
            {
                blnResult = false;
            }

            return blnResult;
        }

        //validates zip
        public static bool ValidZip(string temp)
        {
            bool blnResult = true;

            //val total length of zip
            if(temp.Length < 5)
            {
                blnResult = false;
            }
            else if(temp.Length > 5)
            {
                blnResult = false;
            }

            return blnResult;
        }

        //validates state
        public static bool ValidState(string temp)
        {
            bool blnResult = true;

            //val length of state abr
            if(temp.Length == 2)
            {
                blnResult = true;
            }
            else
            {
                blnResult = false;
            }
            
            return blnResult;
        }


    }
}
