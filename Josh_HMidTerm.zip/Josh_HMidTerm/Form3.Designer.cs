﻿namespace Josh_HMidTerm
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSearch = new System.Windows.Forms.Button();
            this.lblFeedback = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.strFName = new System.Windows.Forms.TextBox();
            this.strLName = new System.Windows.Forms.TextBox();
            this.dgbResults = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgbResults)).BeginInit();
            this.SuspendLayout();
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(860, 312);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(228, 75);
            this.btnSearch.TabIndex = 0;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.BtnSearch_Click);
            // 
            // lblFeedback
            // 
            this.lblFeedback.AutoSize = true;
            this.lblFeedback.Location = new System.Drawing.Point(920, 474);
            this.lblFeedback.Name = "lblFeedback";
            this.lblFeedback.Size = new System.Drawing.Size(110, 32);
            this.lblFeedback.TabIndex = 1;
            this.lblFeedback.Text = "Results";
            this.lblFeedback.Click += new System.EventHandler(this.Label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(659, 102);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(152, 32);
            this.label2.TabIndex = 2;
            this.label2.Text = "First Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(1113, 102);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(151, 32);
            this.label3.TabIndex = 3;
            this.label3.Text = "Last Name";
            // 
            // strFName
            // 
            this.strFName.Location = new System.Drawing.Point(648, 220);
            this.strFName.Name = "strFName";
            this.strFName.Size = new System.Drawing.Size(229, 38);
            this.strFName.TabIndex = 4;
            // 
            // strLName
            // 
            this.strLName.Location = new System.Drawing.Point(1119, 220);
            this.strLName.Name = "strLName";
            this.strLName.Size = new System.Drawing.Size(192, 38);
            this.strLName.TabIndex = 5;
            // 
            // dgbResults
            // 
            this.dgbResults.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgbResults.Location = new System.Drawing.Point(51, 570);
            this.dgbResults.Name = "dgbResults";
            this.dgbResults.RowHeadersWidth = 102;
            this.dgbResults.RowTemplate.Height = 40;
            this.dgbResults.Size = new System.Drawing.Size(1950, 608);
            this.dgbResults.TabIndex = 6;
            this.dgbResults.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DgbResults_CellContentClick);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2011, 1212);
            this.Controls.Add(this.dgbResults);
            this.Controls.Add(this.strLName);
            this.Controls.Add(this.strFName);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblFeedback);
            this.Controls.Add(this.btnSearch);
            this.Name = "Form3";
            this.Text = "Form3";
            ((System.ComponentModel.ISupportInitialize)(this.dgbResults)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Label lblFeedback;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox strFName;
        private System.Windows.Forms.TextBox strLName;
        private System.Windows.Forms.DataGridView dgbResults;
    }
}