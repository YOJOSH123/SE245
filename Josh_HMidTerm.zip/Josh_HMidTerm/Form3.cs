﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Josh_HMidTerm
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Label1_Click(object sender, EventArgs e)
        {
            
        }

        private void DgbResults_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string strPersons_ID = dgbResults.Rows[e.RowIndex].Cells[0].Value.ToString();
            MessageBox.Show(strPersons_ID);

            int intPersons_ID = Convert.ToInt32(strPersons_ID);

            Form1 Editor = new Form1(intPersons_ID);
            Editor.ShowDialog();
        }

        private void BtnSearch_Click(object sender, EventArgs e)
        {
            PersonV2 temp = new PersonV2();
            DataSet ds = temp.SearchPersons(strFName.Text, strLName.Text);

            dgbResults.DataSource = ds;
            dgbResults.DataMember = ds.Tables["Persons_Temp"].ToString();
        }
    }
}
