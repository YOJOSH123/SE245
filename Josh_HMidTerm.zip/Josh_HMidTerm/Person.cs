﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Josh_HMidTerm
{
    public class Person
    {
        private string fName;
        private string mName;
        private string lName;
        private string street1;
        private string street2;
        private string city;
        private string state;
        private string zip;
        private string phone;
        private string email;

        protected string feedback;

        //gets/sets name
        //first name
        public string FName
        {
            get { return fName; }
            set { fName = value; }
        }
        //middle name
        public string MName
        {
            get { return mName; }
            set { mName = value; }
        }
        //last name
        public string LName
        {
            get { return lName; }
            set { lName = value; }
        }

        //gets/sets address
        //gets street1
        public string Street1
        {
            get
            {
                return street1;
            }
            set
            {
                street1 = value;
            }
        }
        //gets street2
        public string Street2
        {
            get
            {
                return street2;
            }
            set
            {
                street2 = value;
            }
        }
        //gets city
        public string City
        {
            get
            {
                return city;
            }
            set
            {
                city = value;
            }
        }
        //gets state
        public string State
        {
            get
            {
                return state;
            }
            set
            {
                if (Validation.ValidState(value))
                {
                    state = value;
                }
                else
                {
                    feedback += "\nInvalid State abbrevition";
                }
            }
        }
        //gets zip
        public string Zip
        {
            get
            {
                return zip;
            }
            set
            {
                if (Validation.ValidZip(value))
                {
                    zip = value;
                }
                else
                {
                    feedback += "\nInvalid Zip ";
                }
            }
        }

        //gets/sets contact info
        //gets phone
        public string Phone
        {
            get
            {
                return phone;
            }
            set
            {
                if(Validation.ValidPhone(value))
                {
                    phone = value;
                }
                else
                {
                    feedback += "\nInvalid Phone";
                }
                
            }
        }
        //gets email
        public string Email
        {
            get
            {
                return email;
            }
            set
            {
                if(Validation.ValidEmail(value))
                {
                    email = value;
                }
                else
                {
                    feedback += "\nInvalid Email";
                }
                
            }
        }

        public string Feedback
        {
            get { return feedback; }         
        }


        public Person()
        {
            fName = "";
            mName = "";
            lName = "";
            street1 = "";
            street2 = "";
            city = "";
            state = "";
            zip = "";
            phone = "";
            email = "";
        }
    }
}
