﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Josh_HMidTerm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            MessageBox.Show("Hello there....Annoyed yet???");
            this.BackColor = Color.Crimson;
        }

        private void BtnSubmit_Click(object sender, EventArgs e)
        {
            Customer temp = new Customer();

           

            //fills person variable/object
            //name
            temp.FName = txtFName.Text;
            temp.MName = txtMName.Text;
            temp.LName = txtLName.Text;
            //address
            temp.Street1 = txtStreet1.Text;
            temp.Street2 = txtStreet2.Text;
            temp.City = txtCity.Text;
            temp.State = txtState.Text;
            temp.Zip = txtZip.Text;
            //contact info
            temp.Phone = txtPhone.Text;
            temp.Email = txtEmail.Text;

            //Person2
            //Cell phone
            temp.Cell_phone = txtCPhone.Text;
            //facebook
            temp.FaceBook = txtFaceBook.Text;

            //Customer
            //
            temp.Customer_since = txtCSince.Value;
            temp.Total_purchases = txtTPurchases.Value;
            temp.Discount_member = txtDMember.Text;
            temp.Rewards_earned = txtREarned.Value;

        //output what we stored
            lblFeedback.Text = temp.FName + "\n" + temp.MName + "\n" + temp.LName 
                                + "\n" + temp.Street1 + "\n" + temp.Street2 + "\n" + temp.City + "\n" + temp.State + "\n" + temp.Zip
                                + "\n" + temp.Phone + "\n" + temp.Email + "\n" + temp.Cell_phone + "\n" + temp.FaceBook+"\n" + temp.Customer_since + "\n" + temp.Total_purchases
                                + "\n" + temp.Discount_member + "\n" + temp.Rewards_earned;

            if (!temp.Feedback.Contains("ERROR:"))
            {
                lblFeedback.Text += temp.AddARecord();   //if no errors weh setting values, then perform the insertion into db
            }
            else
            {
                lblFeedback.Text += temp.Feedback;       //else...dispay the error msg
            }
        }

        public Form1(int intPersons_ID)
        {
            InitializeComponent();  //Creates and init's all form objects

            //Gather info about this one person and store it in a datareader
            PersonV2 temp = new PersonV2();
            SqlDataReader dr = temp.FindOnePerson(intPersons_ID);

            //Use that info to fill out the form
            //Loop thru the records stored in the reader 1 record at a time
            // Note that since this is based on one person's ID, then we
            //  should only have one record
            while (dr.Read())
            {
                //Take the Name(s) from the datareader and copy them
                // into the appropriate text fields
                txtFName.Text = dr["First"].ToString();
                txtMName.Text = dr["Middle"].ToString();
                txtLName.Text = dr["Last"].ToString();
                txtStreet1.Text = dr["Street1"].ToString();
                txtStreet2.Text = dr["Street2"].ToString();
                txtCity.Text = dr["City"].ToString();
                txtState.Text = dr["State"].ToString();
                txtZip.Text = dr["Zip"].ToString();
                txtPhone.Text = dr["Phone"].ToString();
                txtFaceBook.Text = dr["FaceBook"].ToString();
                lblPersons_ID.Text = dr["Persons_ID"].ToString();

                //We added this one to store the ID in a new label
                lblPersons_ID.Text = dr["Persons_ID"].ToString();
            }


        }

        private void LblFeedback_Click(object sender, EventArgs e)
        {

        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            Int32 intPersons_ID = Convert.ToInt32(lblPersons_ID.Text);

            PersonV2 temp = new PersonV2();

            lblFeedback.Text = temp.DeleteOnePerson(intPersons_ID);
        }

        private void BtnUpdate_Click(object sender, EventArgs e)
        {
            PersonV2 temp = new PersonV2();

            //fills person variable/object
            //name
            temp.FName = txtFName.Text;
            temp.MName = txtMName.Text;
            temp.LName = txtLName.Text;
            //address
            temp.Street1 = txtStreet1.Text;
            temp.Street2 = txtStreet2.Text;
            temp.City = txtCity.Text;
            temp.State = txtState.Text;
            temp.Zip = txtZip.Text;
            //contact info
            temp.Phone = txtPhone.Text;
            temp.Email = txtEmail.Text;
            //Person2
            //facebook
            temp.FaceBook = txtFaceBook.Text;

            temp.Persons_ID = Convert.ToInt32(lblPersons_ID.Text);

            if (!temp.Feedback.Contains("Error:"))
            {
                lblFeedback.Text = temp.UpdateARecord();
            }
            else
            {
                lblFeedback.Text = temp.Feedback;
            }
        }
    }
}

