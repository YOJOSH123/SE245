﻿namespace Josh_HMidTerm
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtFName = new System.Windows.Forms.TextBox();
            this.txtMName = new System.Windows.Forms.TextBox();
            this.txtLName = new System.Windows.Forms.TextBox();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblFeedback = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txtStreet1 = new System.Windows.Forms.TextBox();
            this.txtZip = new System.Windows.Forms.TextBox();
            this.txtState = new System.Windows.Forms.TextBox();
            this.txtCity = new System.Windows.Forms.TextBox();
            this.txtStreet2 = new System.Windows.Forms.TextBox();
            this.txtPhone = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.txtFaceBook = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtDMember = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.txtCPhone = new System.Windows.Forms.TextBox();
            this.txtCSince = new System.Windows.Forms.DateTimePicker();
            this.txtTPurchases = new System.Windows.Forms.NumericUpDown();
            this.txtREarned = new System.Windows.Forms.NumericUpDown();
            this.lblPersons_ID = new System.Windows.Forms.Label();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.txtTPurchases)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtREarned)).BeginInit();
            this.SuspendLayout();
            // 
            // txtFName
            // 
            this.txtFName.Location = new System.Drawing.Point(346, 224);
            this.txtFName.Name = "txtFName";
            this.txtFName.Size = new System.Drawing.Size(261, 38);
            this.txtFName.TabIndex = 0;
            // 
            // txtMName
            // 
            this.txtMName.Location = new System.Drawing.Point(346, 296);
            this.txtMName.Name = "txtMName";
            this.txtMName.Size = new System.Drawing.Size(261, 38);
            this.txtMName.TabIndex = 1;
            // 
            // txtLName
            // 
            this.txtLName.Location = new System.Drawing.Point(346, 374);
            this.txtLName.Name = "txtLName";
            this.txtLName.Size = new System.Drawing.Size(261, 38);
            this.txtLName.TabIndex = 5;
            // 
            // btnSubmit
            // 
            this.btnSubmit.BackColor = System.Drawing.Color.MidnightBlue;
            this.btnSubmit.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.btnSubmit.Location = new System.Drawing.Point(1418, 500);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(220, 72);
            this.btnSubmit.TabIndex = 6;
            this.btnSubmit.Text = "Submit Person";
            this.btnSubmit.UseVisualStyleBackColor = false;
            this.btnSubmit.Click += new System.EventHandler(this.BtnSubmit_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(159, 230);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(152, 32);
            this.label1.TabIndex = 7;
            this.label1.Text = "First Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(141, 302);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(182, 32);
            this.label2.TabIndex = 8;
            this.label2.Text = "Middle Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(172, 380);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(151, 32);
            this.label3.TabIndex = 9;
            this.label3.Text = "Last Name";
            // 
            // lblFeedback
            // 
            this.lblFeedback.AutoSize = true;
            this.lblFeedback.BackColor = System.Drawing.Color.LightSteelBlue;
            this.lblFeedback.Location = new System.Drawing.Point(1428, 831);
            this.lblFeedback.Name = "lblFeedback";
            this.lblFeedback.Size = new System.Drawing.Size(110, 32);
            this.lblFeedback.TabIndex = 10;
            this.lblFeedback.Text = "Results";
            this.lblFeedback.Click += new System.EventHandler(this.LblFeedback_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.MintCream;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label4.Location = new System.Drawing.Point(786, 38);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(328, 46);
            this.label4.TabIndex = 11;
            this.label4.Text = "Person Info Form";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(738, 230);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(114, 32);
            this.label5.TabIndex = 12;
            this.label5.Text = "Street 1";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(738, 302);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(114, 32);
            this.label6.TabIndex = 13;
            this.label6.Text = "Street 2";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(788, 380);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(64, 32);
            this.label7.TabIndex = 14;
            this.label7.Text = "City";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(770, 456);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(82, 32);
            this.label8.TabIndex = 15;
            this.label8.Text = "State";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(797, 540);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(55, 32);
            this.label9.TabIndex = 16;
            this.label9.Text = "Zip";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(1169, 236);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(180, 32);
            this.label10.TabIndex = 17;
            this.label10.Text = "Home Phone";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(1262, 357);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(87, 32);
            this.label11.TabIndex = 18;
            this.label11.Text = "Email";
            // 
            // txtStreet1
            // 
            this.txtStreet1.Location = new System.Drawing.Point(884, 224);
            this.txtStreet1.Name = "txtStreet1";
            this.txtStreet1.Size = new System.Drawing.Size(261, 38);
            this.txtStreet1.TabIndex = 19;
            // 
            // txtZip
            // 
            this.txtZip.Location = new System.Drawing.Point(884, 534);
            this.txtZip.Name = "txtZip";
            this.txtZip.Size = new System.Drawing.Size(261, 38);
            this.txtZip.TabIndex = 20;
            // 
            // txtState
            // 
            this.txtState.Location = new System.Drawing.Point(884, 450);
            this.txtState.Name = "txtState";
            this.txtState.Size = new System.Drawing.Size(261, 38);
            this.txtState.TabIndex = 21;
            // 
            // txtCity
            // 
            this.txtCity.Location = new System.Drawing.Point(884, 374);
            this.txtCity.Name = "txtCity";
            this.txtCity.Size = new System.Drawing.Size(261, 38);
            this.txtCity.TabIndex = 22;
            // 
            // txtStreet2
            // 
            this.txtStreet2.Location = new System.Drawing.Point(884, 296);
            this.txtStreet2.Name = "txtStreet2";
            this.txtStreet2.Size = new System.Drawing.Size(261, 38);
            this.txtStreet2.TabIndex = 23;
            // 
            // txtPhone
            // 
            this.txtPhone.Location = new System.Drawing.Point(1377, 230);
            this.txtPhone.Name = "txtPhone";
            this.txtPhone.Size = new System.Drawing.Size(261, 38);
            this.txtPhone.TabIndex = 24;
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(1377, 351);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(261, 38);
            this.txtEmail.TabIndex = 25;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(340, 135);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(90, 32);
            this.label12.TabIndex = 26;
            this.label12.Text = "Name";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(878, 135);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(119, 32);
            this.label13.TabIndex = 27;
            this.label13.Text = "Address";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(1371, 135);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(167, 32);
            this.label14.TabIndex = 28;
            this.label14.Text = "Contact Info";
            // 
            // txtFaceBook
            // 
            this.txtFaceBook.Location = new System.Drawing.Point(1377, 429);
            this.txtFaceBook.Name = "txtFaceBook";
            this.txtFaceBook.Size = new System.Drawing.Size(261, 38);
            this.txtFaceBook.TabIndex = 29;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(1206, 432);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(143, 32);
            this.label15.TabIndex = 30;
            this.label15.Text = "FaceBook";
            // 
            // txtDMember
            // 
            this.txtDMember.Location = new System.Drawing.Point(346, 797);
            this.txtDMember.Name = "txtDMember";
            this.txtDMember.Size = new System.Drawing.Size(261, 38);
            this.txtDMember.TabIndex = 33;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(340, 521);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(191, 32);
            this.label16.TabIndex = 35;
            this.label16.Text = "Customer Info";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(12, 589);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(216, 32);
            this.label17.TabIndex = 36;
            this.label17.Text = "Customer Since";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(91, 697);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(220, 32);
            this.label18.TabIndex = 37;
            this.label18.Text = "Total Purchases";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(15, 803);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(308, 32);
            this.label19.TabIndex = 38;
            this.label19.Text = "Discount Member (Y/N)";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(86, 914);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(225, 32);
            this.label20.TabIndex = 39;
            this.label20.Text = "Rewards Earned";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(1194, 296);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(155, 32);
            this.label21.TabIndex = 40;
            this.label21.Text = "Cell Phone";
            // 
            // txtCPhone
            // 
            this.txtCPhone.Location = new System.Drawing.Point(1377, 289);
            this.txtCPhone.Name = "txtCPhone";
            this.txtCPhone.Size = new System.Drawing.Size(261, 38);
            this.txtCPhone.TabIndex = 41;
            // 
            // txtCSince
            // 
            this.txtCSince.Location = new System.Drawing.Point(249, 589);
            this.txtCSince.Name = "txtCSince";
            this.txtCSince.Size = new System.Drawing.Size(494, 38);
            this.txtCSince.TabIndex = 42;
            // 
            // txtTPurchases
            // 
            this.txtTPurchases.DecimalPlaces = 2;
            this.txtTPurchases.Location = new System.Drawing.Point(346, 695);
            this.txtTPurchases.Maximum = new decimal(new int[] {
            1316134912,
            2328,
            0,
            0});
            this.txtTPurchases.Name = "txtTPurchases";
            this.txtTPurchases.Size = new System.Drawing.Size(261, 38);
            this.txtTPurchases.TabIndex = 43;
            // 
            // txtREarned
            // 
            this.txtREarned.DecimalPlaces = 2;
            this.txtREarned.Location = new System.Drawing.Point(346, 912);
            this.txtREarned.Maximum = new decimal(new int[] {
            1215752192,
            23,
            0,
            0});
            this.txtREarned.Name = "txtREarned";
            this.txtREarned.Size = new System.Drawing.Size(261, 38);
            this.txtREarned.TabIndex = 44;
            // 
            // lblPersons_ID
            // 
            this.lblPersons_ID.AutoSize = true;
            this.lblPersons_ID.Location = new System.Drawing.Point(86, 66);
            this.lblPersons_ID.Name = "lblPersons_ID";
            this.lblPersons_ID.Size = new System.Drawing.Size(155, 32);
            this.lblPersons_ID.TabIndex = 45;
            this.lblPersons_ID.Text = "Person_ID:";
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(1418, 589);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(231, 79);
            this.btnUpdate.TabIndex = 46;
            this.btnUpdate.Text = "Update Person";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.BtnUpdate_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(1417, 697);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(232, 75);
            this.btnDelete.TabIndex = 47;
            this.btnDelete.Text = "Delete Book";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.BtnDelete_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Crimson;
            this.ClientSize = new System.Drawing.Size(1880, 1133);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.lblPersons_ID);
            this.Controls.Add(this.txtREarned);
            this.Controls.Add(this.txtTPurchases);
            this.Controls.Add(this.txtCSince);
            this.Controls.Add(this.txtCPhone);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.txtDMember);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.txtFaceBook);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.txtPhone);
            this.Controls.Add(this.txtStreet2);
            this.Controls.Add(this.txtCity);
            this.Controls.Add(this.txtState);
            this.Controls.Add(this.txtZip);
            this.Controls.Add(this.txtStreet1);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lblFeedback);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.txtLName);
            this.Controls.Add(this.txtMName);
            this.Controls.Add(this.txtFName);
            this.Name = "Form1";
            this.Text = "Josh\'s MidTerm";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.txtTPurchases)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtREarned)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtFName;
        private System.Windows.Forms.TextBox txtMName;
        private System.Windows.Forms.TextBox txtLName;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblFeedback;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtStreet1;
        private System.Windows.Forms.TextBox txtZip;
        private System.Windows.Forms.TextBox txtState;
        private System.Windows.Forms.TextBox txtCity;
        private System.Windows.Forms.TextBox txtStreet2;
        private System.Windows.Forms.TextBox txtPhone;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtFaceBook;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtDMember;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox txtCPhone;
        private System.Windows.Forms.DateTimePicker txtCSince;
        private System.Windows.Forms.NumericUpDown txtTPurchases;
        private System.Windows.Forms.NumericUpDown txtREarned;
        private System.Windows.Forms.Label lblPersons_ID;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnDelete;
    }
}

