﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Josh_HMidTerm
{
    class Customer: PersonV2
    {
        private DateTime customer_since;
        private decimal total_purchases;
        private string discount_member;
        private decimal rewards_earned;

        public DateTime Customer_since
        {
            get
            {
                return customer_since;
            }
            set
            {
                customer_since = value;
            }
        }

        public decimal Total_purchases
        {
            get
            {
                return total_purchases;
            }
            set
            {
                total_purchases = value;
            }
        }

        public string Discount_member
        {
            get
            {
                return discount_member;
            }
            set
            {
                discount_member = value;
            }
        }

        public decimal Rewards_earned
        {
            get
            {
                return rewards_earned;
            }
            set
            {
                rewards_earned = value;
            }
        }

        public Customer()
        {
            total_purchases = 0;
            discount_member = "";
            rewards_earned = 0;
        }

    }
}
